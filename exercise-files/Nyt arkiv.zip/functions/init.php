<?php ob_start();

session_start();

/********* DELETE when it goes on air *********/
ini_set('display_errors', 'On');
/********* DELETE when it goes on air *********/
include("db.php");
include("functions.php");
