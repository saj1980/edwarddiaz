<?php

$con = mysqli_connect('localhost', 'mdbuser9772478', 'PsVsH9Z4', 'mysql5-7num3.webhosting.dk');

// MySQL Server/hostname	mysql5-7num3.webhosting.dk
// Login/username	mdbuser9772478
// Database	mdbuser9772478
// Password	PsVsH9Z4
// MySQL version	5.7


function row_count($result){

	return mysqli_num_rows($result);
}


function escape($string) {
	global $con;
	return mysqli_real_escape_string($con, $string);

}


function confirm( $result) {
	global $con;
		if (!$result) {
			die( 'QUERY FAILED BIG TIME'. mysqli_error($con));
		}
}




function query($query) {

	global $con;

	$result =  mysqli_query($con, $query);

	confirm($result);

	return $result;
}


function fetch_array($result) {

	global $con;
	mysqli_fetch_array($result);

	return mysqli_fetch_array($result);
}